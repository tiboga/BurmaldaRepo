#ifndef RUL_CORE_H
#define RUL_CORE_H
#include <stddef.h>
#include <stdio.h>

#define RUL_COLS 21
#define RUL_TYPES 33

typedef struct {
    double hours, days;
    char *id, *type;
    unsigned order;
    unsigned band;
} Machine;

typedef struct {
    Machine *rows;
    size_t count, capacity, bands[3], missing[RUL_COLS], bad_rows, no_hours, unknown_types, anomalies, years, type_count;
    size_t truth_count, label_count, labels_matched;
    size_t tp, fp, fn;
    unsigned missing_columns;
    double absolute_error;
    const char *error;
} Data;

typedef void (*ReportProgress)(size_t);

size_t type_count(void);
const char *type_name(size_t index);
const char *column_name(size_t index);
double number(const char *text);
int missing_number(double number);
double predict(const char *type, double *features, size_t *anomalies, size_t *years);
unsigned risk_band(double days);
void analyze(FILE *input, Data *result, ReportProgress progress);
void release_data(Data *data);
int write_results(FILE *out, const Data *data);
#endif
