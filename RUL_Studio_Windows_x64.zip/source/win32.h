#ifndef RUL_WIN32_H
#define RUL_WIN32_H
#include <stdint.h>
#include <stddef.h>
#include <wchar.h>

typedef void *Handle;
typedef uintptr_t UP;
typedef intptr_t IP;
typedef unsigned U;
typedef uint32_t Color;
typedef const wchar_t *Text;
typedef struct { int x,y; } Point;
typedef struct { int l,t,r,b; } Rect;
typedef struct { Handle hwnd; U message; UP wparam; IP lparam; U time; Point point; U private; } Message;
typedef struct { Handle dc; int erase; Rect dirty; int restore,incremental; unsigned char reserved[32]; } Paint;
typedef struct {
    U size,style;
    IP (*proc)(Handle,U,UP,IP);
    int class_extra,window_extra;
    Handle instance,icon,cursor,background;
    Text menu,name;
    Handle small_icon;
} WindowClass;
typedef struct {
    U size;
    Handle owner,instance;
    Text filter;
    wchar_t *custom_filter;
    U custom_size,filter_index;
    wchar_t *file;
    U file_size;
    wchar_t *file_title;
    U title_size;
    Text initial_folder,title;
    U flags;
    uint16_t file_offset,extension_offset;
    Text default_extension;
    IP data;
    void *hook;
    Text template_name;
    void *reserved;
    U reserved_word, flags_ex;
} FileDialog;
typedef struct { U type,id,item,action,state; Handle window,dc; Rect bounds; UP data; } DrawItem;
typedef struct { Point reserved,max_size,max_position,min_track,max_track; } MinMax;

Handle GetModuleHandleW(Text);
U GetModuleFileNameW(Handle,wchar_t*,U);
void ExitProcess(U);
int CloseHandle(Handle);
int MultiByteToWideChar(U,U,const char*,int,wchar_t*,int);
int WideCharToMultiByte(U,U,Text,int,char*,int,const char*,int*);
int SetProcessDPIAware(void);
int SystemParametersInfoW(U,U,void*,U);
uint16_t RegisterClassExW(const WindowClass*);
Handle CreateWindowExW(U,Text,Text,U,int,int,int,int,Handle,Handle,Handle,void*);
int ShowWindow(Handle,int);
int UpdateWindow(Handle);
int GetMessageW(Message*,Handle,U,U);
int TranslateMessage(const Message*);
IP DispatchMessageW(const Message*);
IP DefWindowProcW(Handle,U,UP,IP);
int DestroyWindow(Handle);
void PostQuitMessage(int);
int PostMessageW(Handle,U,UP,IP);
IP SendMessageW(Handle,U,UP,IP);
int IsDialogMessageW(Handle,Message*);
Handle LoadCursorW(Handle,Text);
Handle LoadIconW(Handle,Text);
Handle BeginPaint(Handle,Paint*);
int EndPaint(Handle,const Paint*);
int GetClientRect(Handle,Rect*);
int InvalidateRect(Handle,const Rect*,int);
int MoveWindow(Handle,int,int,int,int,int);
int GetWindowTextW(Handle,wchar_t*,int);
int SetWindowTextW(Handle,Text);
int EnableWindow(Handle,int);
int MessageBoxW(Handle,Text,Text,U);
int FillRect(Handle,const Rect*,Handle);
int DrawTextW(Handle,Text,int,Rect*,U);
int DrawFocusRect(Handle,const Rect*);
int GetOpenFileNameW(FileDialog*);
int GetSaveFileNameW(FileDialog*);
Handle CreateSolidBrush(Color);
Handle CreatePen(int,int,Color);
Handle CreateFontW(int,int,int,int,int,U,U,U,U,U,U,U,U,Text);
Handle SelectObject(Handle,Handle);
int DeleteObject(Handle);
int DeleteDC(Handle);
Handle CreateCompatibleDC(Handle);
Handle CreateCompatibleBitmap(Handle,int,int);
int BitBlt(Handle,int,int,int,int,Handle,int,int,U);
U SetTextColor(Handle,Color);
int SetBkMode(Handle,int);
int RoundRect(Handle,int,int,int,int,int,int);
int Ellipse(Handle,int,int,int,int);
#endif
