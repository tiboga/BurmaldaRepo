#include "core.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    short left, right;
    unsigned char missing_left, feature;
    float value;
    uint64_t right_categories;
} TreeNode;

#include "model_data.h"

#define COUNT(a) (sizeof(a) / sizeof((a)[0]))
static const unsigned invalid_columns[] = {3,4,5,8,16};
static const unsigned sparse_columns[] = {14,15,16,17};

size_t type_count(void) { return COUNT(types); }
const char *type_name(size_t i) { return i < COUNT(types) ? types[i] : ""; }
const char *column_name(size_t i) {
    if (i == 0) return "Machine_ID";
    if (i <= COLUMN_COUNT) return columns[i-1];
    return "Remaining_Useful_Life_days";
}

static double nan_value(void) { return __builtin_nan(""); }
int missing_number(double x) { return !__builtin_isfinite(x); }

static int whitespace(char c) { return c == ' ' || c == '\t'; }
double number(const char *s) {
    while (whitespace(*s)) s++;
    if (!*s) return nan_value();
    char *end;
    double value = strtod(s,&end);
    if (*end == ',' && end != s) {
        char converted[128];
        size_t len = strlen(s);
        if (len >= sizeof(converted)) return nan_value();
        memcpy(converted,s,len+1);
        converted[end-s] = '.';
        value = strtod(converted,&end);
        if (end == converted) return nan_value();
        while (whitespace(*end)) end++;
        return *end || missing_number(value) ? nan_value() : value;
    }
    if (end == s) return nan_value();
    while (whitespace(*end)) end++;
    return *end || missing_number(value) ? nan_value() : value;
}

static unsigned category(const char *value) {
    for (unsigned i=0; i<COUNT(types); i++)
        if (!strcmp(value,types[i])) return i;
    return COUNT(types);
}

static int truthy(const char *s) {
    if (!strcmp(s,"1") || !strcmp(s,"1.0") || !strcmp(s,"да")) return 1;
    return strlen(s)==4 && (s[0]=='t'||s[0]=='T') && (s[1]=='r'||s[1]=='R') &&
           (s[2]=='u'||s[2]=='U') && (s[3]=='e'||s[3]=='E');
}

double predict(const char *type, double *raw, size_t *anomalies, size_t *years) {
    float x[FEATURE_COUNT];
    for (unsigned i=0; i<COLUMN_COUNT; i++) x[i]=(float)raw[i];
    unsigned cat = category(type);
    x[0] = cat == COUNT(types) ? (float)nan_value() : (float)cat;
    unsigned offset = COLUMN_COUNT;
    for (unsigned i=0; i<COUNT(invalid_columns); i++) {
        unsigned j = invalid_columns[i];
        int invalid = raw[j] < 0;
        x[offset++] = (float)invalid;
        if (invalid) {
            x[j] = (float)nan_value();
            if (anomalies) (*anomalies)++;
        }
    }
    for (unsigned i=0; i<COUNT(sparse_columns); i++) x[offset++] = !missing_number(x[sparse_columns[i]]);
    int invalid_year = raw[1] > 2025;
    x[offset] = (float)invalid_year;
    if (invalid_year) {
        x[1] = 2024;
        if (years) (*years)++;
    }
    for (unsigned j=0; j<COLUMN_COUNT; j++) {
        if (!bounds[j][1] || missing_number(x[j])) continue;
        if (raw[j] < bounds[j][0]) x[j]=(float)bounds[j][0];
        if (raw[j] > bounds[j][1]) x[j]=(float)bounds[j][1];
    }
    float adjustment = base_score;
    for (unsigned i=0; i<COUNT(tree_starts); i++) {
        const TreeNode *tree = tree_nodes+tree_starts[i];
        const TreeNode *node = tree;
        while (node->left >= 0) {
            float value = x[node->feature];
            int left;
            if (missing_number(value)) left = node->missing_left;
            else if (node->right_categories) left = !(node->right_categories & (1ULL<<(unsigned)value));
            else left = value < node->value;
            node = tree + (left ? node->left : node->right);
        }
        adjustment += node->value;
    }
    double hours = missing_number(raw[2]) ? median_hours : raw[2];
    double days = intercept + slope*hours + adjustment;
    return days > 0 ? days : 0;
}

unsigned risk_band(double days) { return days < 7 ? 0 : days < 30 ? 1 : 2; }

typedef struct {
    FILE *source;
    unsigned char buffer[32768];
    size_t pos, end;
    int saved, delimiter;
    char *text;
    size_t used, capacity;
    size_t offsets[2048], fields;
} Csv;

static int byte(Csv *csv) {
    if (csv->saved >= 0) {
        int c=csv->saved;
        csv->saved=-1;
        return c;
    }
    if (csv->pos == csv->end) {
        csv->end=fread(csv->buffer,1,sizeof(csv->buffer),csv->source);
        csv->pos=0;
        if (!csv->end) return EOF;
    }
    return csv->buffer[csv->pos++];
}

static int push(Csv *csv, int c) {
    if (csv->used == csv->capacity) {
        size_t cap=csv->capacity ? csv->capacity*2 : 1024;
        if (cap > 16*1024*1024) return 0;
        char *p=realloc(csv->text,cap);
        if (!p) return 0;
        csv->text=p;
        csv->capacity=cap;
    }
    csv->text[csv->used++]=(char)c;
    return 1;
}

static int next_row(Csv *csv, int header) {
    csv->used=0;
    csv->fields=1;
    csv->offsets[0]=0;
    int in_quote=0, at_start=1, c;
    unsigned separators[3]={0};
    while ((c=byte(csv))!=EOF) {
        if (in_quote) {
            if (c=='"') {
                int next=byte(csv);
                if (next=='"') {
                    if (!push(csv,c)) return -1;
                } else {
                    in_quote=0;
                    csv->saved=next;
                }
            } else if (!push(csv,c)) return -1;
            continue;
        }
        if (c=='"' && at_start) {
            in_quote=1;
            at_start=0;
            continue;
        }
        if (c=='\r' || c=='\n') {
            if (c=='\r') {
                int next=byte(csv);
                if (next!='\n') csv->saved=next;
            }
            if (csv->used) break;
            continue;
        }
        if (c==0) return -1;
        if (header && (c==','||c==';'||c=='\t')) {
            unsigned i=c==','?0:c==';'?1:2;
            separators[i]++;
            if (!push(csv,1+(int)i)) return -1;
            at_start=1;
        } else if (!header && c==csv->delimiter) {
            if (csv->fields==COUNT(csv->offsets) || !push(csv,0)) return -1;
            csv->offsets[csv->fields++]=csv->used;
            at_start=1;
        } else {
            if (!push(csv,c)) return -1;
            at_start=0;
        }
    }
    if (in_quote || ferror(csv->source)) return -1;
    if (!csv->used) return 0;
    if (header) {
        unsigned best=0;
        for (unsigned i=1;i<3;i++) if (separators[i]>separators[best]) best=i;
        csv->delimiter=",;\t"[best];
        for (size_t i=0;i<csv->used;i++) {
            unsigned code=(unsigned char)csv->text[i];
            if (code==best+1) {
                if (csv->fields==COUNT(csv->offsets)) return -1;
                csv->text[i]=0;
                csv->offsets[csv->fields++]=i+1;
            } else if (code>=1 && code<=3) csv->text[i]=",;\t"[code-1];
        }
    }
    return push(csv,0) ? 1 : -1;
}

static char *field(Csv *csv, int index) {
    if (index<0) return "";
    char *p=csv->text+csv->offsets[index];
    while (whitespace(*p)) p++;
    size_t n=strlen(p);
    while (n && whitespace(p[n-1])) p[--n]=0;
    return p;
}

static int blank(const char *text) {
    return !*text || !strcmp(text,"NaN") || !strcmp(text,"nan") || !strcmp(text,"NA") || !strcmp(text,"NULL") || !strcmp(text,"null");
}

static int by_days(const void *a, const void *b) {
    const Machine *x=a,*y=b;
    if (x->days!=y->days) return x->days < y->days ? -1 : 1;
    return (x->order>y->order)-(x->order<y->order);
}

void analyze(FILE *input, Data *d, ReportProgress progress) {
    Csv *csv=calloc(1,sizeof(*csv));
    if (!csv) { d->error="Недостаточно памяти."; return; }
    csv->source=input;
    csv->saved=-1;
    csv->end=fread(csv->buffer,1,sizeof(csv->buffer),input);
    if (csv->end>=3 && !memcmp(csv->buffer,"\xef\xbb\xbf",3)) csv->pos=3;
    int rc=next_row(csv,1), index[RUL_COLS], label_ix=-1, recognized=0;
    for (unsigned i=0;i<RUL_COLS;i++) index[i]=-1;
    if (rc!=1) {
        d->error="Не удалось прочитать заголовок CSV.";
        goto done;
    }
    size_t width=csv->fields;
    for (size_t i=0;i<width;i++) {
        const char *h=field(csv,(int)i);
        if (!strcmp(h,"Failure_Within_7_Days")) label_ix=(int)i;
        for (unsigned j=0;j<RUL_COLS;j++) {
            if (strcmp(h,column_name(j))) continue;
            if (index[j]>=0) {
                d->error="В CSV есть повторяющиеся столбцы.";
                goto done;
            }
            index[j]=(int)i;
            if (j<RUL_COLS-1) recognized++;
        }
    }
    if (index[3]<0 || recognized<5) {
        d->error="Нужны Operational_Hours и ещё четыре столбца формата проекта.";
        goto done;
    }
    for (unsigned i=1;i<RUL_COLS-1;i++) if(index[i]<0) d->missing_columns++;
    uint64_t seen=0;
    while ((rc=next_row(csv,0))>0) {
        if (csv->fields!=width) { d->bad_rows++; continue; }
        if (d->count==d->capacity) {
            size_t cap=d->capacity ? d->capacity*2 : 4096;
            if (cap > 4194304) { d->error="Файл содержит больше 4 194 304 строк."; goto done; }
            Machine *rows=realloc(d->rows,cap*sizeof(Machine));
            if (!rows) { d->error="Недостаточно памяти."; goto done; }
            d->rows=rows;
            d->capacity=cap;
        }
        double values[COLUMN_COUNT];
        for (unsigned i=0;i<RUL_COLS;i++) {
            const char *p=field(csv,index[i]);
            if (blank(p)) d->missing[i]++;
            if (i==0 || i>=RUL_COLS-1) continue;
            values[i-1]=i==13 ? truthy(p) : number(p);
        }
        char fallback[32];
        const char *id=field(csv,index[0]), *type=field(csv,index[1]);
        if (blank(id)) {
            sprintf(fallback,"#%u",(unsigned)d->count+1);
            id=fallback;
        }
        unsigned cat=category(type);
        if (cat==COUNT(types)) d->unknown_types++;
        else seen|=1ULL<<cat;
        if (missing_number(values[2])) d->no_hours++;
        size_t il=strlen(id)+1, tl=strlen(type)+1;
        char *storage=malloc(il+tl);
        if (!storage) { d->error="Недостаточно памяти."; goto done; }
        memcpy(storage,id,il);
        memcpy(storage+il,type,tl);
        double p=predict(type,values,&d->anomalies,&d->years);
        unsigned band=risk_band(p);
        d->rows[d->count]=(Machine){values[2],p,storage,storage+il,(unsigned)d->count,band};
        d->bands[band]++;
        double actual=number(field(csv,index[RUL_COLS-1]));
        if (!missing_number(actual)) {
            d->truth_count++;
            double error=p-actual;
            d->absolute_error+=error<0?-error:error;
        }
        const char *label=field(csv,label_ix);
        int failure=truthy(label);
        if (failure || !strcmp(label,"False") || !strcmp(label,"false") || !strcmp(label,"FALSE") || !strcmp(label,"0")) {
            d->label_count++;
            d->labels_matched+=!missing_number(actual) && (actual<7)==failure;
            d->tp+= failure && band==0;
            d->fp+= !failure && band==0;
            d->fn+= failure && band!=0;
        }
        d->count++;
        if (progress && d->count%5000==0) progress(d->count);
    }
    for (;seen;seen&=seen-1) d->type_count++;
    if (rc<0) d->error="Не удалось разобрать CSV. Проверьте кавычки и формат строк.";
    else if (!d->count) d->error="В CSV нет строк с данными.";
    else if (d->no_hours*2>d->count) d->error="Менее половины строк содержат числовую наработку.";
    else qsort(d->rows,d->count,sizeof(Machine),by_days);
done:
    free(csv->text);
    free(csv);
}

void release_data(Data *d) {
    for (size_t i=0;i<d->count;i++) free(d->rows[i].id);
    free(d->rows);
    memset(d,0,sizeof(*d));
}

static void csv_text(FILE *f, const char *s) {
    fputc('"',f);
    for (;*s;s++) { if (*s=='"') fputc('"',f); fputc(*s,f); }
    fputc('"',f);
}

int write_results(FILE *out, const Data *d) {
    fputs("\xef\xbb\xbfMachine_ID,Machine_Type,Operational_Hours,Predicted_RUL_days,RUL_band\r\n",out);
    for (size_t i=0;i<d->count;i++) {
        const Machine *m=d->rows+i;
        csv_text(out,m->id); fputc(',',out);
        csv_text(out,m->type); fputc(',',out);
        if (!missing_number(m->hours)) fprintf(out,"%.12g",m->hours);
        fprintf(out,",%.1f,%s\r\n",m->days,m->band==0?"under_7":m->band==1?"7_to_30":"30_plus");
    }
    return !ferror(out);
}
