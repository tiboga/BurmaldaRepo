#include "win32.h"
#include "core.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define RGB(r,g,b) ((Color)((r)|((g)<<8)|((b)<<16)))
#define COUNT(v) (sizeof(v)/sizeof((v)[0]))
#define NOTIFY(code) ((U)(code)<<16)
#define SHOW 5
#define WS_CHILD 0x40000000U
#define WS_VISIBLE 0x10000000U
#define WS_TABSTOP 0x00010000U
#define WS_OVERLAPPEDWINDOW 0x00cf0000U
#define WM_DONE 0x8001U
#define WM_PROGRESS 0x8002U
#define WM_SETFONT 0x30U
#define SINGLE 0x20U
#define VERTICAL 0x4U
#define ELLIPSIS 0x8000U
#define NO_PREFIX 0x800U

enum { NAV_FLEET=100,NAV_AUDIT,NAV_MANUAL,OPEN,DEMO,SAVE,SEARCH,PREV,NEXT,CALCULATE,TYPE,FIELD };
static const Color paper=RGB(244,246,243), white=RGB(255,255,255), ink=RGB(28,42,37);
static const Color muted=RGB(84,103,94), sidebar=RGB(22,40,33), lime=RGB(219,249,111);
static const Color line=RGB(219,227,220), light=RGB(234,241,236), mint=RGB(144,174,156);
static const Color red=RGB(156,48,38), green=RGB(39,104,73);
static const Color band_fill[]={RGB(255,235,230),RGB(255,244,219),RGB(231,245,235)};
static const Color band_text[]={RGB(156,48,38),RGB(132,83,16),RGB(39,104,73)};
static const Text band_labels[]={L"Меньше 7 дней",L"От 7 до 30 дней",L"30 дней и больше"};
static const Color bar_color[]={RGB(218,107,88),RGB(232,178,91),RGB(136,183,154)};
static Handle window,instance,nav[3],open_btn,demo_btn,save_btn,search_box,prev_btn,next_btn,calc_btn,type_box,fields[7];
static Handle font_small,font_body,font_bold,font_title,font_number,font_brand;
static Data dataset,pending;
static int busy,view,scale_dpi=96;
static int demo_file;
static unsigned page_index;
static size_t *hits, hit_count;
static wchar_t status_line[512], loaded_name[512], path_in[32768];
static double manual_days;
static int manual_ready;
static wchar_t manual_error[160];
static const unsigned manual_columns[]={2,1,3,4,5,8,6};
static const Text field_labels[]={L"Наработка, ч *",L"Год установки",L"Температура, °C",L"Вибрация, мм/с",L"Шум, дБ",L"Мощность, кВт",L"Уровень масла, %"};

extern FILE *_wfopen(Text,Text);
extern int _snwprintf(wchar_t*,size_t,Text,...);
extern UP _beginthreadex(void*,U,U (*)(void*),void*,U,U*);

static int px(int n) { return (n*scale_dpi+48)/96; }
static Rect logical(int x,int y,int w,int h) { return (Rect){px(x),px(y),px(x+w),px(y+h)}; }
static void refresh(void) { InvalidateRect(window,0,0); }

static void copy_text(wchar_t *out,size_t capacity,Text value) {
    size_t i=0;
    while (i+1<capacity && value[i]) { out[i]=value[i]; i++; }
    out[i]=0;
}

static void wide(const char *s,wchar_t *buf,int n) {
    if (!MultiByteToWideChar(65001,0,s,-1,buf,n)) {
        size_t len=strlen(s);
        int bytes=len<(size_t)(n-1) ? (int)len : n-1;
        int used=MultiByteToWideChar(65001,0,s,bytes,buf,n-1);
        buf[used]=0;
    }
}

static void narrow(Text s,char *buf,int n) {
    if (!WideCharToMultiByte(65001,0,s,-1,buf,n,0,0)) buf[0]=0;
}

static void t(Handle dc, Text s, Handle font, Color color,int x,int y,int w,int h,U flags) {
    Rect rect=logical(x,y,w,h);
    Handle previous=SelectObject(dc,font);
    SetTextColor(dc,color);
    SetBkMode(dc,1);
    DrawTextW(dc,s,-1,&rect,flags|NO_PREFIX);
    SelectObject(dc,previous);
}

static void box(Handle dc,int x,int y,int w,int h,Color color) {
    if (w<=0 || h<=0) return;
    Rect r=logical(x,y,w,h);
    Handle brush=CreateSolidBrush(color);
    FillRect(dc,&r,brush);
    DeleteObject(brush);
}

static void rounded(Handle dc,int x,int y,int w,int h,int radius,Color color,Color border) {
    if (w<=0 || h<=0) return;
    Rect r=logical(x,y,w,h);
    Handle brush=CreateSolidBrush(color);
    Handle pen=CreatePen(0,1,border);
    Handle old_brush=SelectObject(dc,brush), old_pen=SelectObject(dc,pen);
    RoundRect(dc,r.l,r.t,r.r,r.b,px(radius),px(radius));
    SelectObject(dc,old_pen); SelectObject(dc,old_brush);
    DeleteObject(pen); DeleteObject(brush);
}

static void grouped(unsigned value,wchar_t *out) {
    wchar_t temporary[24];
    int n=_snwprintf(temporary,COUNT(temporary),L"%u",value);
    unsigned j=0;
    for (int i=0;i<n;i++) {
        if (i && (n-i)%3==0) out[j++]=L' ';
        out[j++]=temporary[i];
    }
    out[j]=0;
}

static void days_text(double value,wchar_t *out,size_t capacity) {
    _snwprintf(out,capacity,L"%.1f",value);
    for (size_t i=0;i<capacity && out[i];i++) if (out[i]==L'.') out[i]=L',';
    out[capacity-1]=0;
}

static Handle control(Text cls,Text label,U style,unsigned id) {
    Handle h=CreateWindowExW(0,cls,label,WS_CHILD|WS_TABSTOP|style,0,0,8,8,window,(Handle)(UP)id,instance,0);
    SendMessageW(h,WM_SETFONT,(UP)font_body,0);
    return h;
}
static Handle button(Text label,unsigned id) { return control(L"BUTTON",label,11,id); }
static void place(Handle h,int on,int x,int y,int w,int height) {
    if (on) MoveWindow(h,px(x),px(y),px(w),px(height),1);
    ShowWindow(h,on ? SHOW : 0);
}

static unsigned row_capacity(int client_h) {
    int free_height=client_h-466;
    if (free_height<38) return 1;
    return (unsigned)(free_height/32);
}
static int visible_width(void) {
    Rect r;
    GetClientRect(window,&r);
    return r.r*96/scale_dpi;
}
static int visible_height(void) {
    Rect r;
    GetClientRect(window,&r);
    return r.b*96/scale_dpi;
}

static void layout(void) {
    int w=visible_width(), h=visible_height();
    int fleet=view==0, manual=view==2, has=dataset.count>0;
    for (int i=0;i<3;i++) place(nav[i],1,18,150+i*48,182,40);
    place(open_btn,fleet,w-310,50,144,37);
    place(demo_btn,fleet,w-154,50,124,37);
    place(save_btn,fleet&&has,w-162,310,112,33);
    place(search_box,fleet&&has,w-402,310,222,33);
    place(prev_btn,fleet&&has,266,h-51,92,32);
    place(next_btn,fleet&&has,369,h-51,92,32);
    place(type_box,manual,274,182,226,340);
    for (int i=0;i<7;i++) place(fields[i],manual,274+(i%2)*116,254+(i/2)*66,108,31);
    place(calc_btn,manual,274,526,226,39);
    EnableWindow(open_btn,!busy);
    EnableWindow(demo_btn,!busy);
    EnableWindow(save_btn,has);
    if (has) {
        unsigned rows=row_capacity(h);
        unsigned last=hit_count ? (unsigned)((hit_count-1)/rows) : 0;
        if (page_index>last) page_index=last;
        EnableWindow(prev_btn,page_index>0);
        EnableWindow(next_btn,page_index<last);
    }
}

static void section_title(Handle dc,Text tag,Text title,Text subtitle,int width) {
    t(dc,tag,font_bold,green,248,26,width-278,20,SINGLE);
    t(dc,title,font_title,ink,248,49,width-280,43,SINGLE);
    t(dc,subtitle,font_body,muted,250,100,width-280,24,SINGLE|ELLIPSIS);
}

static void left_side(Handle dc,int height) {
    box(dc,0,0,218,height,sidebar);
    rounded(dc,20,30,42,42,11,lime,lime);
    t(dc,L"R",font_brand,sidebar,20,30,42,42,SINGLE|VERTICAL|1);
    t(dc,L"RUL Studio",font_brand,white,74,27,132,28,SINGLE);
    t(dc,L"Данные для нейросетей",font_small,mint,74,59,133,19,SINGLE);
    box(dc,20,103,178,1,RGB(59,82,67));
    t(dc,L"РАБОЧАЯ ОБЛАСТЬ",font_small,mint,22,122,174,17,SINGLE);
    box(dc,20,height-105,178,1,RGB(59,82,67));
    t(dc,L"Учебный проект",font_bold,white,22,height-84,175,22,SINGLE);
    t(dc,L"CODERRA  /  1-й семестр",font_small,mint,22,height-57,175,20,SINGLE);
}

static void score_card(Handle dc,int x,int y,int w,Text label,Text number,Text detail,Color bg,Color accent) {
    rounded(dc,x,y,w,105,18,bg,bg==white?line:bg);
    t(dc,label,font_bold,accent,x+14,y+12,w-28,19,SINGLE|ELLIPSIS);
    t(dc,number,font_number,accent,x+14,y+30,w-28,45,SINGLE|ELLIPSIS);
    t(dc,detail,font_small,muted,x+15,y+79,w-30,18,SINGLE|ELLIPSIS);
}

static int search_hit(const char *value,const char *query) {
    for (const char *p=value;*p;p++) {
        const unsigned char *x=(const unsigned char*)p,*y=(const unsigned char*)query;
        while (*x && *y) {
            int a=*x,b=*y;
            if (a>='A'&&a<='Z') a+=32;
            if (b>='A'&&b<='Z') b+=32;
            if (a!=b) break;
            x++; y++;
        }
        if (!*y) return 1;
    }
    return 0;
}

static void run_search(void) {
    wchar_t query[160];
    char utf8[640];
    GetWindowTextW(search_box,query,COUNT(query));
    narrow(query,utf8,COUNT(utf8));
    free(hits); hits=0;
    page_index=0;
    hit_count=dataset.count;
    if (*utf8 && dataset.count) {
        hits=malloc(dataset.count*sizeof(*hits));
        if (hits) {
            hit_count=0;
            for (size_t i=0;i<dataset.count;i++)
                if (search_hit(dataset.rows[i].id,utf8) || search_hit(dataset.rows[i].type,utf8)) hits[hit_count++]=i;
        }
    }
    layout();
    refresh();
}

static void draw_fleet(Handle dc,int w,int h) {
    int x=248, right=w-30, area=right-x, card_w=(area-36)/4;
    section_title(dc,L"ПРОГНОЗ ОБОРУДОВАНИЯ",L"Парк станков",L"Остаточный ресурс оборудования по данным CSV",w);
    wchar_t n[32];
    grouped((unsigned)dataset.count,n);
    score_card(dc,x,140,card_w,L"Всего станков",dataset.count?n:L"—",L"Строк в анализе",white,ink);
    for (int i=0;i<3;i++) {
        grouped((unsigned)dataset.bands[i],n);
        score_card(dc,x+(i+1)*(card_w+12),140,card_w,band_labels[i],dataset.count?n:L"—",L"Прогноз ресурса",band_fill[i],band_text[i]);
    }
    if (!dataset.count) {
        rounded(dc,x,270,area,h-303,20,white,line);
        rounded(dc,x+26,300,58,44,12,light,light);
        t(dc,L"CSV",font_bold,green,x+26,300,58,44,SINGLE|VERTICAL|1);
        t(dc,L"Загрузите список оборудования",font_brand,ink,x+28,362,area-55,40,SINGLE);
        t(dc,L"Подойдут исходный датасет проекта и проверочные CSV. Данные обрабатываются на компьютере.",font_body,muted,x+28,408,area-56,62,0x10);
        t(dc,L"Демо-файл содержит 4 000 станков и известные метки из проверочной выборки.",font_body,muted,x+28,470,area-56,62,0x10);
        if (*status_line) t(dc,status_line,font_bold,busy?green:red,x+28,h-98,area-56,49,0x10);
        return;
    }
    int bar_left=x+2, bar_w=area-4, pos=bar_left;
    for (int i=0;i<3;i++) {
        int width=i==2 ? bar_left+bar_w-pos : (int)(dataset.bands[i]*bar_w/dataset.count);
        box(dc,pos,260,width,7,bar_color[i]);
        pos+=width;
    }
    t(dc,*status_line?status_line:loaded_name,font_small,*status_line?(busy?green:red):muted,x+2,277,area-4,24,SINGLE|ELLIPSIS);
    rounded(dc,x,301,area,h-322,18,white,line);
    t(dc,L"Прогноз по станкам",font_bold,ink,x+16,314,area-425,24,SINGLE|ELLIPSIS);
    int left=x+17, type_x=x+area*27/100, hours_x=x+area*52/100, result_x=x+area*69/100;
    int band_x=x+area*81/100;
    box(dc,left,359,area-34,26,light);
    t(dc,L"Станок",font_small,muted,left+6,362,type_x-left-7,20,SINGLE);
    t(dc,L"Тип оборудования",font_small,muted,type_x,362,hours_x-type_x-8,20,SINGLE|ELLIPSIS);
    t(dc,L"Наработка, ч",font_small,muted,hours_x,362,result_x-hours_x-8,20,SINGLE|ELLIPSIS);
    t(dc,L"Ресурс, дн.",font_small,muted,result_x,362,band_x-result_x-7,20,SINGLE|ELLIPSIS);
    unsigned room=row_capacity(h);
    size_t start=(size_t)page_index*room, end=start+room;
    if (end>hit_count) end=hit_count;
    for (size_t j=start;j<end;j++) {
        const Machine *m=dataset.rows+(hits?hits[j]:j);
        int y=390+(int)(j-start)*32;
        wchar_t id[140],type[140],number[40],hours[40];
        wide(m->id,id,COUNT(id)); wide(m->type,type,COUNT(type));
        if (missing_number(m->hours)) copy_text(hours,COUNT(hours),L"—");
        else _snwprintf(hours,COUNT(hours),L"%.0f",m->hours);
        days_text(m->days,number,COUNT(number));
        t(dc,id,font_bold,ink,left+6,y,type_x-left-12,25,SINGLE|VERTICAL|ELLIPSIS);
        t(dc,*type?type:L"—",font_body,muted,type_x,y,hours_x-type_x-11,25,SINGLE|VERTICAL|ELLIPSIS);
        t(dc,hours,font_body,muted,hours_x,y,result_x-hours_x-10,25,SINGLE|VERTICAL|ELLIPSIS);
        t(dc,number,font_bold,band_text[m->band],result_x,y,band_x-result_x-5,25,SINGLE|VERTICAL|ELLIPSIS);
        rounded(dc,band_x,y+2,area-(band_x-x)-18,21,9,band_fill[m->band],band_fill[m->band]);
        Text badge=m->band==0?L"< 7":m->band==1?L"7–<30":L"30+";
        t(dc,badge,font_small,band_text[m->band],band_x,y+2,area-(band_x-x)-18,21,SINGLE|VERTICAL|1);
        box(dc,left,y+28,area-35,1,line);
    }
    if (!hit_count) t(dc,L"По этому запросу станки не найдены.",font_body,muted,left+6,398,area-42,40,SINGLE);
    wchar_t pages[95];
    if (hit_count) _snwprintf(pages,COUNT(pages),L"%u–%u из %u",(unsigned)start+1,(unsigned)end,(unsigned)hit_count);
    else copy_text(pages,COUNT(pages),L"0 результатов");
    t(dc,pages,font_small,muted,480,h-48,area-250,25,SINGLE|VERTICAL);
}

static void draw_audit(Handle dc,int w,int h) {
    int area=w-278;
    section_title(dc,L"ПРОВЕРКА ВХОДНЫХ ДАННЫХ",L"Аудит данных",L"Пропуски, предобработка и оценка по известным меткам",w);
    if (!dataset.count) {
        rounded(dc,248,145,area,153,18,white,line);
        t(dc,L"Загрузите CSV во вкладке «Парк станков».",font_bold,ink,270,170,area-44,31,SINGLE);
        t(dc,L"Результаты аудита появятся после расчёта.",font_body,muted,270,213,area-44,30,SINGLE);
        return;
    }
    int width=(area-20)/2;
    rounded(dc,248,145,width,278,18,white,line);
    rounded(dc,268+width,145,width,278,18,white,line);
    t(dc,L"Заполненность полей",font_brand,ink,267,163,width-35,31,SINGLE);
    t(dc,L"Поля с наибольшей долей пустых значений",font_small,muted,267,201,width-35,24,SINGLE|ELLIPSIS);
    unsigned indices[RUL_COLS-2];
    for (unsigned i=0;i<COUNT(indices);i++) indices[i]=i+1;
    for (unsigned i=0;i<5;i++) {
        unsigned best=i;
        for (unsigned j=i+1;j<COUNT(indices);j++)
            if (dataset.missing[indices[j]]>dataset.missing[indices[best]]) best=j;
        unsigned k=indices[best];
        indices[best]=indices[i]; indices[i]=k;
        wchar_t title[80], value[40];
        wide(column_name(k),title,COUNT(title));
        int y=233+(int)i*34;
        unsigned percent=(unsigned)(dataset.missing[k]*1000/dataset.count);
        _snwprintf(value,COUNT(value),L"%u,%u%%",percent/10,percent%10);
        t(dc,title,font_small,muted,267,y,width-105,20,SINGLE|ELLIPSIS);
        t(dc,value,font_bold,green,248+width-75,y,58,20,SINGLE|2);
        box(dc,268,y+21,width-40,5,light);
        box(dc,268,y+21,(int)(percent*(width-40)/1000),5,RGB(133,179,151));
    }
    int rx=286+width;
    t(dc,L"Что изменилось при очистке",font_brand,ink,rx,163,width-34,30,SINGLE|ELLIPSIS);
    const struct { Text name; size_t amount; } audit[]={
        {L"Год после 2025 заменён на 2024",dataset.years},
        {L"Отрицательные показания стали пропусками",dataset.anomalies},
        {L"Строки без числовой наработки",dataset.no_hours},
        {L"Строки без известного типа станка",dataset.unknown_types},
        {L"Входные столбцы отсутствовали",dataset.missing_columns},
        {L"Строки с неверным числом полей",dataset.bad_rows}
    };
    for (unsigned i=0;i<COUNT(audit);i++) {
        wchar_t value[32];
        grouped((unsigned)audit[i].amount,value);
        int y=210+(int)i*31;
        t(dc,audit[i].name,font_small,muted,rx,y,width-102,24,SINGLE|VERTICAL|ELLIPSIS);
        t(dc,value,font_bold,ink,248+area-84,y,64,24,SINGLE|VERTICAL|2);
    }
    rounded(dc,248,445,area,h-477,18,white,line);
    t(dc,L"Оценка по загруженным меткам",font_brand,ink,267,465,area-45,33,SINGLE);
    if (dataset.truth_count || dataset.label_count) {
        wchar_t message[220], number[36];
        int y=515;
        if (dataset.truth_count) {
            days_text(dataset.absolute_error/dataset.truth_count,number,COUNT(number));
            _snwprintf(message,COUNT(message),L"MAE  %ls дня    ·    Строк с известным ресурсом: %u",number,(unsigned)dataset.truth_count);
            t(dc,message,font_bold,green,269,y,area-48,25,SINGLE|ELLIPSIS);
            y+=39;
        }
        if (dataset.label_count) {
            _snwprintf(message,COUNT(message),L"Порог < 7 дней    ·    Найдено: %u    ·    Ложные тревоги: %u    ·    Пропущено: %u",
                        (unsigned)dataset.tp,(unsigned)dataset.fp,(unsigned)dataset.fn);
            t(dc,message,font_body,muted,269,y,area-48,31,0x10);
        }
    } else t(dc,L"В файле нет известных значений RUL или меток отказа.",font_body,muted,269,515,area-45,42,0x10);
}

static void draw_manual(Handle dc,int w,int h) {
    int right=w-30, width=right-550;
    section_title(dc,L"РАСЧЁТ ПО ПАРАМЕТРАМ",L"Карточка станка",L"Введите наработку и доступные показания оборудования.",w);
    rounded(dc,248,138,280,h-166,18,white,line);
    t(dc,L"Тип оборудования",font_small,muted,275,156,223,20,SINGLE);
    for (int i=0;i<7;i++) t(dc,field_labels[i],font_small,muted,274+(i%2)*116,232+(i/2)*66,111,20,SINGLE|ELLIPSIS);
    if (*manual_error) t(dc,manual_error,font_small,red,274,580,226,58,0x10);
    unsigned band=manual_ready?risk_band(manual_days):2;
    Color bg=manual_ready?band_fill[band]:light, fg=manual_ready?band_text[band]:ink;
    rounded(dc,550,138,width,240,18,bg,bg);
    t(dc,L"ОСТАТОЧНЫЙ РЕСУРС",font_bold,fg,576,165,width-54,26,SINGLE);
    wchar_t result[48]=L"—";
    if (manual_ready) days_text(manual_days,result,COUNT(result));
    t(dc,result,font_number,fg,576,207,width-54,50,SINGLE|ELLIPSIS);
    t(dc,L"дней",font_body,fg,578,263,width-54,25,SINGLE);
    t(dc,manual_ready?band_labels[band]:L"Результат появится после расчёта",font_bold,fg,578,315,width-56,26,SINGLE|ELLIPSIS);
    rounded(dc,550,399,width,133,18,white,line);
    t(dc,L"Как считается прогноз",font_brand,ink,574,419,width-50,31,SINGLE);
    t(dc,L"Линейная оценка по наработке плюс поправка XGBoost. Пустые показания обрабатываются как пропуски.",font_body,muted,574,462,width-49,49,0x10);
}

static void draw_window(void) {
    Paint paint;
    Handle target=BeginPaint(window,&paint);
    Rect r;
    GetClientRect(window,&r);
    if (r.r<=0 || r.b<=0) { EndPaint(window,&paint); return; }
    Handle back=CreateCompatibleDC(target);
    Handle bitmap=back?CreateCompatibleBitmap(target,r.r,r.b):0;
    Handle old=bitmap?SelectObject(back,bitmap):0;
    Handle dc=bitmap?back:target;
    int w=r.r*96/scale_dpi, h=r.b*96/scale_dpi;
    box(dc,0,0,w+2,h+2,paper);
    left_side(dc,h);
    if (view==0) draw_fleet(dc,w,h);
    else if (view==1) draw_audit(dc,w,h);
    else draw_manual(dc,w,h);
    if (bitmap) {
        BitBlt(target,0,0,r.r,r.b,back,0,0,0x00cc0020U);
        SelectObject(back,old);
        DeleteObject(bitmap);
    }
    if (back) DeleteDC(back);
    EndPaint(window,&paint);
}

static void draw_button(const DrawItem *item) {
    int side=item->id>=NAV_FLEET && item->id<=NAV_MANUAL;
    int active=side && (int)item->id-NAV_FLEET==view;
    int primary=item->id==OPEN || item->id==CALCULATE;
    int down=(item->state&1)!=0, disabled=(item->state&4)!=0;
    Color back=side?sidebar:paper, fg=ink, edge=line;
    if (side) {
        fg=active?sidebar:RGB(231,240,232);
        edge=down?RGB(53,77,64):(active?lime:sidebar);
        back=edge;
    } else if (primary) {
        back=disabled?light:down?RGB(49,85,65):sidebar;
        fg=disabled?muted:white;
        edge=back;
    } else {
        back=disabled?paper:down?light:white;
        fg=disabled?muted:ink;
    }
    Rect r=item->bounds;
    Handle brush=CreateSolidBrush(back);
    Handle pen=CreatePen(0,1,edge);
    Handle before=SelectObject(item->dc,brush), pn=SelectObject(item->dc,pen);
    FillRect(item->dc,&item->bounds,brush);
    RoundRect(item->dc,r.l,r.t,r.r,r.b,px(12),px(12));
    SelectObject(item->dc,pn); SelectObject(item->dc,before);
    DeleteObject(pen); DeleteObject(brush);
    if (side && active) {
        Rect marker={r.l+px(10),r.t+px(14),r.l+px(14),r.b-px(14)};
        Handle dot=CreateSolidBrush(sidebar);
        FillRect(item->dc,&marker,dot);
        DeleteObject(dot);
    }
    wchar_t label[80];
    GetWindowTextW(item->window,label,COUNT(label));
    Handle old=SelectObject(item->dc,font_bold);
    SetTextColor(item->dc,fg); SetBkMode(item->dc,1);
    if (side) r.l+=px(23);
    DrawTextW(item->dc,label,-1,&r,SINGLE|VERTICAL|NO_PREFIX|(side?0:1));
    SelectObject(item->dc,old);
    if (item->state&16) {
        r=item->bounds;
        r.l+=px(5); r.t+=px(5); r.r-=px(5); r.b-=px(5);
        DrawFocusRect(item->dc,&r);
    }
}

static void select_view(int which) {
    view=which;
    for (int i=0;i<3;i++) InvalidateRect(nav[i],0,0);
    layout();
    refresh();
}

static int open_dialog(wchar_t *path,U size,int save) {
    const wchar_t filter[]=L"Таблицы CSV (*.csv)\0*.csv\0Все файлы (*.*)\0*.*\0";
    FileDialog dialog={0};
    dialog.size=sizeof(dialog);
    dialog.owner=window;
    dialog.filter=filter;
    dialog.filter_index=1;
    dialog.file=path;
    dialog.file_size=size;
    dialog.title=save?L"Сохранить прогноз":L"Открыть таблицу оборудования";
    dialog.default_extension=L"csv";
    dialog.flags=0x80000U|0x800U|0x8U|(save?2U:0x1000U);
    return save?GetSaveFileNameW(&dialog):GetOpenFileNameW(&dialog);
}

static void on_progress(size_t count) { PostMessageW(window,WM_PROGRESS,(UP)count,0); }
static U worker(void *unused) {
    (void)unused;
    FILE *input=_wfopen(path_in,L"rb");
    if (input) {
        analyze(input,&pending,on_progress);
        fclose(input);
    } else pending.error=demo_file?"Демо-файл check_test.csv должен находиться рядом с приложением.":"Не удалось открыть выбранный файл.";
    PostMessageW(window,WM_DONE,0,0);
    return 0;
}

static void start_import(int demo) {
    if (busy) return;
    path_in[0]=0;
    if (demo) {
        U length=GetModuleFileNameW(0,path_in,COUNT(path_in));
        if (!length || length>=COUNT(path_in)) return;
        while (length && path_in[length-1]!=L'\\') length--;
        copy_text(path_in+length,COUNT(path_in)-length,L"check_test.csv");
    } else if (!open_dialog(path_in,COUNT(path_in),0)) return;
    demo_file=demo;
    copy_text(status_line,COUNT(status_line),L"Читаем файл и строим прогноз…");
    busy=1;
    UP thread=_beginthreadex(0,0,worker,0,0,0);
    if (thread) CloseHandle((Handle)thread);
    else {
        busy=0;
        copy_text(status_line,COUNT(status_line),L"Не удалось запустить обработку файла.");
    }
    layout(); refresh();
}

static void finish_import(void) {
    busy=0;
    if (pending.error) {
        wide(pending.error,status_line,COUNT(status_line));
        release_data(&pending);
    } else {
        release_data(&dataset);
        dataset=pending;
        memset(&pending,0,sizeof(pending));
        wchar_t *base=path_in;
        for (wchar_t *p=path_in;*p;p++) if (*p==L'\\'||*p==L'/') base=p+1;
        _snwprintf(loaded_name,COUNT(loaded_name)-1,L"%ls%ls  ·  %u типов из списка модели",demo_file?L"Демо · ":L"",base,(unsigned)dataset.type_count);
        status_line[0]=0;
        SetWindowTextW(search_box,L"");
        run_search();
    }
    layout(); refresh();
}

static void export_results(void) {
    static wchar_t path[32768];
    copy_text(path,COUNT(path),L"rul_predictions.csv");
    if (!open_dialog(path,COUNT(path),1)) return;
    FILE *out=_wfopen(path,L"wb");
    if (out) {
        int okay=write_results(out,&dataset);
        if (fclose(out)!=0) okay=0;
        if (okay) {
            MessageBoxW(window,L"Прогноз по всем строкам сохранён.",L"RUL Studio",0x40);
            return;
        }
    }
    MessageBoxW(window,L"Не удалось полностью записать CSV.",L"RUL Studio",0x10);
}

static void calculate_manual(void) {
    double values[19];
    for (unsigned i=0;i<COUNT(values);i++) values[i]=__builtin_nan("");
    values[12]=0;
    manual_ready=0;
    manual_error[0]=0;
    for (unsigned i=0;i<COUNT(fields);i++) {
        wchar_t text[70];
        char raw[280];
        GetWindowTextW(fields[i],text,COUNT(text));
        narrow(text,raw,COUNT(raw));
        double v=number(raw);
        if ((i==0 || *raw) && missing_number(v)) {
            _snwprintf(manual_error,COUNT(manual_error),L"Введите число в поле «%ls».",field_labels[i]);
            refresh(); return;
        }
        values[manual_columns[i]]=v;
    }
    if (values[2]<0 || values[2]>200000) {
        copy_text(manual_error,COUNT(manual_error),L"Наработка должна быть в диапазоне 0–200 000 часов.");
        refresh(); return;
    }
    IP selected=SendMessageW(type_box,0x147,0,0);
    manual_days=predict(selected>0?type_name((size_t)selected-1):"",values,0,0);
    manual_ready=1;
    refresh();
}

static Handle create_font(int height,int weight) {
    return CreateFontW(-px(height),0,0,0,weight,0,0,0,1,0,0,5,0,L"Segoe UI");
}

static void create_controls(void) {
    font_small=create_font(13,400);
    font_body=create_font(15,400);
    font_bold=create_font(15,650);
    font_title=create_font(39,740);
    font_number=create_font(38,740);
    font_brand=create_font(20,700);
    nav[0]=button(L"Парк станков",NAV_FLEET);
    nav[1]=button(L"Аудит данных",NAV_AUDIT);
    nav[2]=button(L"Ручной расчёт",NAV_MANUAL);
    open_btn=button(L"Открыть CSV",OPEN);
    demo_btn=button(L"Демо",DEMO);
    save_btn=button(L"Выгрузить CSV",SAVE);
    prev_btn=button(L"‹ Назад",PREV);
    next_btn=button(L"Дальше ›",NEXT);
    search_box=CreateWindowExW(0x200,L"EDIT",L"",WS_CHILD|WS_TABSTOP|0x80U,0,0,8,8,window,(Handle)(UP)SEARCH,instance,0);
    SendMessageW(search_box,WM_SETFONT,(UP)font_body,0);
    SendMessageW(search_box,0x1501,0,(IP)L"Поиск по ID или типу");
    SendMessageW(search_box,0xc5,159,0);
    type_box=control(L"COMBOBOX",L"",0x00200003U,TYPE);
    SendMessageW(type_box,0x143,0,(IP)L"Не указан");
    for (size_t i=0;i<type_count();i++) {
        wchar_t name[90];
        wide(type_name(i),name,COUNT(name));
        SendMessageW(type_box,0x143,0,(IP)name);
    }
    SendMessageW(type_box,0x14e,0,0);
    for (unsigned i=0;i<COUNT(fields);i++) {
        fields[i]=CreateWindowExW(0x200,L"EDIT",L"",WS_CHILD|WS_TABSTOP|0x80U,0,0,8,8,window,(Handle)(UP)(FIELD+i),instance,0);
        SendMessageW(fields[i],WM_SETFONT,(UP)font_body,0);
        SendMessageW(fields[i],0xc5,38,0);
    }
    calc_btn=button(L"Рассчитать ресурс",CALCULATE);
}

static IP window_proc(Handle hwnd,U msg,UP w,IP l) {
    switch(msg) {
    case 1:
        window=hwnd;
        create_controls();
        return 0;
    case 5:
        if (w!=1) { layout(); refresh(); }
        return 0;
    case 15:
        draw_window();
        return 0;
    case 20:
        return 1;
    case 36: {
        MinMax *info=(MinMax*)l;
        info->min_track=(Point){px(1020),px(724)};
        return 0;
    }
    case 43:
        draw_button((const DrawItem*)l);
        return 1;
    case 0x111: {
        U id=(U)(w&0xffff), code=(U)(w&0xffff0000);
        if (id==SEARCH && code==NOTIFY(0x300)) run_search();
        if (code!=0) break;
        switch(id) {
        case NAV_FLEET: case NAV_AUDIT: case NAV_MANUAL:
            select_view((int)id-NAV_FLEET);
            break;
        case OPEN: start_import(0); break;
        case DEMO: start_import(1); break;
        case SAVE: export_results(); break;
        case PREV: if (page_index) page_index--; layout(); refresh(); break;
        case NEXT: page_index++; layout(); refresh(); break;
        case CALCULATE: calculate_manual(); break;
        }
        return 0;
    }
    case WM_PROGRESS: {
        wchar_t count[36];
        grouped((unsigned)w,count);
        _snwprintf(status_line,COUNT(status_line),L"Обработано строк: %ls…",count);
        refresh();
        return 0;
    }
    case WM_DONE:
        finish_import();
        return 0;
    case 2:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd,msg,w,l);
}

U GetDpiForSystem(void);

void start(void) {
    SetProcessDPIAware();
    U dpi=GetDpiForSystem();
    if (dpi>=96 && dpi<=384) scale_dpi=(int)dpi;
    Rect available={0,0,1920,1080};
    SystemParametersInfoW(48,0,&available,0);
    int width=available.r-available.l, height=available.b-available.t;
    if (width>0 && width<px(1030)) scale_dpi=width*96/1030;
    if (height>0 && height<px(738)) scale_dpi=height*96/738;
    int initial_width=px(1160), initial_height=px(790);
    if (width>0 && initial_width>width-8) initial_width=width-8;
    if (height>0 && initial_height>height-8) initial_height=height-8;
    instance=GetModuleHandleW(0);
    Handle icon=LoadIconW(instance,(Text)(UP)1);
    WindowClass wc={0};
    wc.size=sizeof(wc);
    wc.proc=window_proc;
    wc.instance=instance;
    wc.icon=icon;
    wc.small_icon=icon;
    wc.cursor=LoadCursorW(0,(Text)(UP)32512);
    wc.name=L"RULStudioDesktop";
    if (!RegisterClassExW(&wc)) ExitProcess(1);
    Handle main=CreateWindowExW(0,wc.name,L"RUL Studio — Данные для нейросетей",WS_OVERLAPPEDWINDOW|0x02000000U,
        (int)0x80000000U,0,initial_width,initial_height,0,0,instance,0);
    if (!main) ExitProcess(1);
    ShowWindow(main,SHOW);
    UpdateWindow(main);
    Message message;
    int status;
    while ((status=GetMessageW(&message,0,0,0))>0) {
        if (message.message==0x100 && message.wparam==13) {
            if (message.hwnd==search_box) continue;
            if (view==2) {
                int input=0;
                for (unsigned i=0;i<COUNT(fields);i++) input|=message.hwnd==fields[i];
                if (input) { calculate_manual(); continue; }
            }
        }
        if (!IsDialogMessageW(main,&message)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }
    ExitProcess(status<0?1:(U)message.wparam);
}
