"""Build a native Windows x64 PE with GCC and binutils on Linux."""
import binascii
from pathlib import Path
import struct
import subprocess
import tempfile
import zlib

HERE = Path(__file__).resolve().parent
BASE = 0x140000000
DLLS = {
    'KERNEL32': 'CloseHandle ExitProcess GetModuleFileNameW GetModuleHandleW MultiByteToWideChar WideCharToMultiByte',
    'USER32': ('BeginPaint CreateWindowExW DefWindowProcW DispatchMessageW DrawFocusRect DrawTextW EnableWindow '
               'EndPaint FillRect GetClientRect GetDpiForSystem GetMessageW GetWindowTextW InvalidateRect '
               'IsDialogMessageW LoadCursorW LoadIconW MessageBoxW MoveWindow PostMessageW PostQuitMessage '
               'RegisterClassExW SendMessageW SetProcessDPIAware SetWindowTextW ShowWindow SystemParametersInfoW TranslateMessage UpdateWindow'),
    'GDI32': ('BitBlt CreateCompatibleBitmap CreateCompatibleDC CreateFontW CreatePen CreateSolidBrush '
              'DeleteDC DeleteObject RoundRect SelectObject SetBkMode SetTextColor'),
    'COMDLG32': 'GetOpenFileNameW GetSaveFileNameW',
    'MSVCRT': ('_beginthreadex _snwprintf _wfopen calloc fclose ferror fprintf fputc fread free fwrite '
               'malloc memcpy qsort realloc sprintf strcmp strlen strtod'),
}

def run(*args):
    subprocess.run(args, check=True)

def import_code():
    lines = [f'.set BASE, {BASE}', '.section .idata$2,"aw"']
    for dll in DLLS:
        lines.append(f'.long lookup_{dll}-BASE,0,0,name_{dll}-BASE,iat_{dll}-BASE')
    lines.append('.long 0,0,0,0,0')
    for part, prefix in [(4,'lookup'),(5,'iat')]:
        lines += [f'.section .idata${part},"aw"', '.balign 8']
        for dll, functions in DLLS.items():
            lines.append(f'{prefix}_{dll}:')
            for fn in functions.split():
                if part == 5: lines.append(f'address_{fn}:')
                lines.append(f'.long hint_{fn}-BASE,0')
            lines.append('.quad 0')
    lines.append('.section .idata$6,"aw"')
    for dll, functions in DLLS.items():
        lines.append(f'name_{dll}: .asciz "{dll}.dll"')
        for fn in functions.split():
            lines.extend(['.balign 2', f'hint_{fn}: .short 0', f'.asciz "{fn}"'])
    lines.append('.text')
    for functions in DLLS.values():
        for fn in functions.split():
            lines += [f'.globl {fn}', f'{fn}: jmp *address_{fn}(%rip)']
    return '\n'.join(lines)+'\n'

def png_icon(size):
    def pixel(x,y):
        x,y=(x+0.5)/size,(y+0.5)/size
        cx=max(0.17,min(0.83,x))
        cy=max(0.17,min(0.83,y))
        if (x-cx)**2+(y-cy)**2>0.16**2: return b'\0\0\0\0'
        color=(23,42,34,255)
        # An ascending set of bars represents remaining service life.
        for lo,hi,top,tone in [(0.24,0.37,0.56,(129,183,148,255)),
                                (0.43,0.56,0.42,(174,218,139,255)),
                                (0.62,0.75,0.26,(219,249,111,255))]:
            if lo<x<hi and top<y<0.76: color=tone
        return bytes(color)
    def chunk(kind,data):
        return struct.pack('>I',len(data))+kind+data+struct.pack('>I',binascii.crc32(kind+data))
    pixels=b''.join(b'\0'+b''.join(pixel(x,y) for x in range(size)) for y in range(size))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(pixels))+chunk(b'IEND',b'')

def resources(directory):
    sizes = (32,48,256)
    icons = [png_icon(i) for i in sizes]
    group = struct.pack('<HHH',0,1,len(icons))
    for i,(size,icon) in enumerate(zip(sizes,icons),1):
        group += struct.pack('<BBBBHHIH',size%256,size%256,0,0,1,32,len(icon),i)
    manifest = b'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity name="RULStudio.Desktop" version="1.0.0.0" processorArchitecture="amd64" type="win32"/>
  <description>RUL Studio</description>
  <dependency><dependentAssembly>
    <assemblyIdentity name="Microsoft.Windows.Common-Controls" version="6.0.0.0" processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*" type="win32"/>
  </dependentAssembly></dependency>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges>
    <requestedExecutionLevel level="asInvoker" uiAccess="false"/>
  </requestedPrivileges></security></trustInfo>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1"><application>
    <supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
  </application></compatibility>
</assembly>'''
    by_type = {3: dict(enumerate(icons,1)),14:{1:group},24:{1:manifest}}
    lines = [f'.set BASE, {BASE}', '.section .rsrc,"a"', '.balign 4', 'resource_root:']
    def table(entries, subdir=True):
        lines.extend(['.long 0,0',f'.short 0,0,0,{len(entries)}'])
        mask = '+0x80000000' if subdir else ''
        lines.extend(f'.long {i},{label}-resource_root{mask}' for i,label in entries)
    table([(kind,f'rs_type_{kind}') for kind in by_type])
    for kind, names in by_type.items():
        lines.append(f'rs_type_{kind}:')
        table([(i,f'rs_lang_{kind}_{i}') for i in names])
    for kind, names in by_type.items():
        for i in names:
            lines.append(f'rs_lang_{kind}_{i}:')
            table([(1033,f'rs_entry_{kind}_{i}')],subdir=False)
    for kind, names in by_type.items():
        for i,value in names.items():
            name=f'{kind}_{i}'
            path=directory/f'rs_{name}.bin'
            path.write_bytes(value)
            lines += [f'rs_entry_{name}: .long rs_blob_{name}-BASE,{len(value)},0,0',
                      '.balign 4',f'rs_blob_{name}: .incbin "{path}"','.balign 4']
    return '\n'.join(lines)+'\n'

def build(out):
    with tempfile.TemporaryDirectory(prefix='rul-build-') as tmp:
        scratch = Path(tmp)
        objects = []
        for source in ('core','desktop'):
            obj = scratch/f'{source}.o'
            run('gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-fshort-wchar','-fno-stack-protector',
                '-fpie','-mno-red-zone','-mabi=ms','-maccumulate-outgoing-args','-fno-asynchronous-unwind-tables',
                '-fno-unwind-tables','-fno-ident','-c',str(HERE/f'{source}.c'),'-o',str(obj))
            objects.append(str(obj))
        for name, code in [('imports',import_code()),('resources',resources(scratch))]:
            asm = scratch/f'{name}.S'
            obj = scratch/f'{name}.o'
            asm.write_text(code)
            run('as',str(asm),'-o',str(obj))
            objects.append(str(obj))
        run('ld','-mi386pep','--image-base',hex(BASE),'--subsystem','windows:6.0',
            '--enable-reloc-section','--no-insert-timestamp','--strip-all','-e','start',*objects,'-o',str(out))

if __name__ == '__main__':
    import sys
    build(Path(sys.argv[1]))
