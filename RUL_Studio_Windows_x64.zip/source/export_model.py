"""Convert the project's trusted joblib snapshot to constant C arrays."""
import math
import re
import struct
import sys
import types

import joblib


class Snapshot:
    def __setstate__(self, values):
        vars(self).update(values)


sys.modules['xgboost'] = types.ModuleType('xgboost')
for module, cls in [('sklearn', 'XGBRegressor'), ('core', 'Booster')]:
    name = 'xgboost.' + module
    sys.modules[name] = types.ModuleType(name)
    setattr(sys.modules[name], cls, type(cls, (Snapshot,), {'__module__': name}))


class UBJSON:
    formats = {b'i':'b', b'U':'B', b'I':'h', b'l':'i', b'L':'q', b'd':'f', b'D':'d'}

    def __init__(self, data):
        self.data = data
        self.pos = 0

    def take(self, size=1):
        start = self.pos
        self.pos += size
        if self.pos > len(self.data):
            raise ValueError('Unexpected end of model')
        return self.data[start:self.pos]

    def peek(self):
        return self.data[self.pos:self.pos + 1]

    def string(self):
        return self.take(self.value()).decode('utf8')

    def container(self, end, item):
        subtype, count = None, None
        if self.peek() == b'$':
            self.take()
            subtype = self.take()
        if self.peek() == b'#':
            self.take()
            count = self.value()
        if count is not None:
            return [item(subtype) for _ in range(count)]
        items = []
        while self.peek() != end:
            items.append(item(subtype))
        self.take()
        return items

    def value(self, tag=None):
        tag = tag or self.take()
        if tag in self.formats:
            fmt = '>' + self.formats[tag]
            return struct.unpack(fmt, self.take(struct.calcsize(fmt)))[0]
        if tag in (b'S', b'H'):
            return self.string()
        if tag == b'C':
            return self.take().decode()
        if tag == b'T':
            return True
        if tag == b'F':
            return False
        if tag == b'Z':
            return None
        if tag == b'[':
            return self.container(b']', self.value)
        if tag == b'{':
            return dict(self.container(b'}', lambda subtype: (self.string(), self.value(subtype))))
        raise ValueError((tag, self.pos, self.data[self.pos-8:self.pos+20]))


def load(path):
    bundle = joblib.load(path)
    stream = UBJSON(bytes(bundle['model']._Booster.handle))
    snap = stream.value()
    assert stream.pos == len(stream.data)
    return bundle, snap['Model']['learner']


def export(bundle, learner, output):
    import json
    import numpy as np

    forest = learner['gradient_booster']['model']
    attrs = learner['attributes']
    assert bundle['prep'] == 'year2024' and bundle['algo'] == 'xgboost-v3'
    assert learner['objective']['name'] == 'reg:absoluteerror'
    assert forest['gbtree_model_param']['num_parallel_tree'] == '1'
    assert learner['feature_names'] == list(bundle['features'])
    trees = forest['trees'][:int(attrs['best_iteration']) + 1]
    categories = forest.get('cats')
    if categories:
        for i, data in enumerate(categories['enc']):
            if isinstance(data, dict) and 'offsets' in data and data['offsets']:
                offsets = data['offsets']
                decoded = [bytes(data['values'][a:b]).decode() for a,b in zip(offsets,offsets[1:])]
                assert i == 0 and decoded == bundle['machine_types']
    base_score = float(learner['learner_model_param']['base_score'].strip('[]'))
    features = list(bundle['features'])
    columns = [c for c in features if not c.endswith(('_was_invalid','_present','_invalid'))]
    widths = [bundle['winsor'].get(c,(0,0)) for c in columns]
    masks = {}
    starts = []
    nodes = []
    for t in trees:
        starts.append(len(nodes))
        masks.clear()
        for node, begin, size in zip(t['categories_nodes'],t['categories_segments'],t['categories_sizes']):
            cats = t['categories'][begin:begin+size]
            assert all(0 <= c < 64 for c in cats)
            masks[node] = sum(1 << c for c in cats)
        for i, (l,r,d,f,v,cat) in enumerate(zip(t['left_children'],t['right_children'],
                        t['default_left'],t['split_indices'],t['split_conditions'],t['split_type'])):
            assert cat == (i in masks)
            assert math.isfinite(v) or cat
            nodes.append((l,r,d,f,v if math.isfinite(v) else 0,masks.get(i,0)))
    def cnum(x):
        return float(x).hex()
    def strs(values):
        return ','.join(json.dumps(s,ensure_ascii=False) for s in values)
    with open(output,'w',encoding='utf8') as f:
        print('/* Generated from rul_model.joblib. */',file=f)
        print('enum { COLUMN_COUNT = %d, FEATURE_COUNT = %d };'%(len(columns),len(features)),file=f)
        print('static const char *const columns[] = {' + strs(columns) + '};',file=f)
        print('static const char *const types[] = {' + strs(bundle['machine_types']) + '};',file=f)
        print('static const double bounds[][2] = {',','.join('{'+cnum(a)+','+cnum(b)+'}' for a,b in widths),'};',file=f)
        print('static const double intercept = %s, slope = %s, median_hours = %s;' %
              tuple(cnum(bundle['base'][k]) for k in ('intercept','slope','median_hours')),file=f)
        print('static const float base_score = %sf;'%cnum(base_score),file=f)
        print('static const unsigned tree_starts[] = {',','.join(map(str,starts)),'};',file=f)
        print('static const TreeNode tree_nodes[] = {',file=f)
        for l,r,d,i,v,mask in nodes:
            print(' {%d,%d,%d,%d,%sf,0x%xULL},'%(l,r,d,i,cnum(v),mask),file=f)
        print('};',file=f)
    return trees, base_score


if __name__ == '__main__':
    b, learner = load(sys.argv[1])
    forest, bias = export(b, learner, sys.argv[2])
    print(f'{len(forest)} prediction trees with base score {bias}')
