#include "core.h"
#include <stdlib.h>
int main(int argc, char **argv) {
    if (argc<2) return 2;
    FILE *input=fopen(argv[1],"rb");
    if (!input) return 2;
    Data d={0};
    analyze(input,&d,NULL);
    fclose(input);
    if (d.error) {
        fprintf(stderr,"%s\n",d.error);
        release_data(&d);
        return 1;
    }
    fprintf(stderr,"rows=%zu bands=%zu/%zu/%zu MAE=%.9f TP=%zu FP=%zu FN=%zu years=%zu negative=%zu types=%zu\n",
            d.count,d.bands[0],d.bands[1],d.bands[2],d.absolute_error/(d.truth_count?d.truth_count:1),d.tp,d.fp,d.fn,d.years,d.anomalies,d.type_count);
    if (argc>2) {
        FILE *out=fopen(argv[2],"wb");
        if (!out || !write_results(out,&d) || fclose(out)) return 2;
    }
    release_data(&d);
    return 0;
}
